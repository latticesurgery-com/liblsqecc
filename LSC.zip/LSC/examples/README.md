Generqted with: python ../../lattice-surgery-compiler/scripts/random_LLI_good_parallelism.py [depth] [width]
