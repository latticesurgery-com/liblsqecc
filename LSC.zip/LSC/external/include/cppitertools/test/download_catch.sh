#!/usr/bin/env sh
wget -c https://github.com/catchorg/Catch2/releases/download/v2.6.0/catch.hpp
