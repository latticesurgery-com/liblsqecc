INPUT="
DeclareLogicalQubitPatches 0,1
"
echo "$INPUT" | lsqecc_slicer -L compact
